<?php
Class Produit {

    private $db;
    private $insert;
    private $select;
    private $selectById;
    private $update;

    
    public function __construct($db){
        $this->db = $db;
        $this->insert = $this->db->prepare("insert into produit(designation, description, prix, idType) values (:designation, :description, :prix, :idType)");
        $this->select = $db->prepare("select p.id, designation, description, prix, t.libelle as libelletype from produit p, type t where p.idType = t.id order by p.id");
        $this->selectById = $db->prepare("select * from produit where id=:id");
        $this->update = $db->prepare("update produit set designation=:designation, description=:description, prix=:prix, idType=:type where id=:id");
    }
    
    public function insert($designation, $description, $prix, $type) {
        $r = true;
        $this->insert->execute(array(':designation' => $designation, ':description' => $description, ':prix' => $prix, ':type' => $type));
        if ($this->insert->errorCode() != 0) {
            print_r($this->insert->errorInfo());
            $r = false;
        }
        return $r;
    }

    public function select(){
        $this->select->execute();
        if ($this->select->errorCode()!=0){
            print_r($this->select->errorInfo());
        }
        return $this->select->fetchAll();
    }

    public function selectById($id) {
        $this->selectById->execute(array(':id' => $id));
        if ($this->selectById->errorCode() != 0) {
            print_r($this->selectById->errorInfo());
        }
        return $this->selectById->fetch();
    }

    public function update($id, $designation, $description, $prix, $type){
        $r = true;
        $this->update->execute(array(':id'=>$id,':designation'=>$designation,':prix'=>$prix ,':description'=>$description ,':type'=>$type));
        if ($this->update->errorCode()!=0){ print_r($this->update->errorInfo());
        $r=false;
        }
        return $r;
    }
}
?>