<?php
$config['serveur']='localhost';
$config['login'] = 'root';
$config['mdp'] ='';
$config['bd'] = 'shopshop';
?>