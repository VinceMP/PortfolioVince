<?php
function getPage($db){
    $lesPages['accueil'] = "accueilControleur";
    $lesPages['contact'] = "contactControleur";
    $lesPages['apropos'] = "aproposControleur";
    $lesPages['mention'] = "mentionControleur";
    $lesPages['inscrire'] = "inscrireControleur";
    $lesPages['maintenance'] = "maintenanceControleur";
    $lesPages['connexion'] = "connexionControleur";
    $lesPages['deconnexion'] = "deconnexionControleur";
    $lesPages['utilisateur'] = "utilisateurControleur";
    $lesPages['utilisateurModif'] = "utilisateurModifControleur";
    $lesPages['produit'] = "produitControleur";
    $lesPages['produitAjout'] = "produitAjoutControleur";
    $lesPages['produitModif'] = "produitModifControleur";
    $lesPages['type'] = "typeControleur";
    $lesPages['typeModif'] = "typeModifControleur";
    $lesPages['typeAjout'] = "typeAjoutControleur";







    if ($db!=null){
        if(isset($_GET['page'])){
            $page = $_GET['page'];
        } else {
            $page = 'accueil' ; 
        }
        if (!isset($lesPages[$page])){
            $page = 'accueil';
        }
        $contenu = $lesPages[$page] ; 
    }
    else {
        $contenu = $lesPages['maintenance'];
    }
    return $contenu ;

}
?>