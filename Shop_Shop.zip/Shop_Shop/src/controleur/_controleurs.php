<?php
require_once 'accueilControleur.php';
require_once 'inscrireControleur.php';
require_once 'connexionControleur.php';
require_once 'deconnexionControleur.php';
require_once 'utilisateurControleur.php';
require_once 'produitControleur.php';
require_once 'typeControleur.php';


?>