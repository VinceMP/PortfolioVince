<?php
function produitControleur($twig,$db){
    $form = array();
    $produit = new Produit($db);
    $liste = $produit->select();

    echo $twig->render('produit.html.twig', array('form'=>$form,'liste'=>$liste));
}

function produitAjoutControleur($twig, $db){
    $form = array();

    if(isset($_POST['btAjouter'])){
        $produit = new Produit($db);
        $designation = $_POST['inputDesignation'];
        $description = $_POST['inputDescription'];
        $prix = $_POST['inputPrix'];
        $idType = $_POST['idType'];
        $exec = $produit->insert($designation, $description, $prix, $idType);
        if(!$exec){
            $form['valide'] = false;
            $form['message'] = 'Problème d\'insertion dans la table produit';
        }
        else{
            $form['valide'] = true;
            $form['message'] = 'Produit ajouté avec succès';
        }
    }


    echo $twig->render('produit-ajout.html.twig', array());
    
}

function produitModifControleur($twig, $db){
    $form = array();
    if(isset($_GET['id'])){
    $produit = new Produit($db);
    $unProduit = $produit->selectById($_GET['id']); 
    if ($unProduit!=null){
        $form['produit'] = $unProduit;
    }
    else{
        $form['message'] = 'produit incorrect';
    }
    }
    else{
        if(isset($_POST['btModifier'])){
            $id = $_POST['id'];
            $designation = $_POST['inputDesignation'];
            $description = $_POST['inputDescription'];
            $prix = $_POST['inputPrix'];
            $type = $_POST['inputLibelle'];
            if(empty($designation)){
                $form['valide'] = false;
                $form['message'] = 'Le champ est vide';
            }
            else{
            $produit = new Produit($db);
            $exec=$produit->update($id, $designation, $description, $prix, $type);
            if(!$exec){
                $form['valide'] = false;
                $form['message'] = 'Echec de la modification';
            }else{
                $form['valide'] = true;
                $form['message'] = 'Modification réussie';
        }
    }
    }else{
        $form['message'] = 'produit non précisé';
    }
}
    echo $twig->render('produit-modif.html.twig', array('form'=>$form));
   }


?>