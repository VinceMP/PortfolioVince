<?php
require_once 'class_utilisateur.php';
require_once 'class_produit.php';
require_once 'class_type.php';
require_once 'class_role.php';
?>