<?php
include __DIR__ . '/connexion.php';  // Utilisez __DIR__ pour obtenir le chemin absolu du répertoire actuel

if (!empty($_GET['idCommande']) && !empty($_GET['idArticle']) && !empty($_GET['quantite'])) {
    $idCommande = $_GET['idCommande'];
    $idArticle = $_GET['idArticle'];
    $quantite = $_GET['quantite'];

    try {
        // Supprimer la commande de la table date_commande
        $sql = "DELETE FROM commande WHERE id = :id";
        $stmt = $connexion->prepare($sql);
        $stmt->bindParam(':id', $idCommande);
        $stmt->execute();

        // Mettre à jour la quantité de l'article dans la table articles
        $sqlUpdate = "UPDATE article SET quantite = quantite + :quantite WHERE id = :idArticle";
        $stmtUpdate = $connexion->prepare($sqlUpdate);
        $stmtUpdate->bindParam(':quantite', $quantite);
        $stmtUpdate->bindParam(':idArticle', $idArticle);
        $stmtUpdate->execute();

        $_SESSION['message'] = [
            'text' => 'Commande annulée avec succès.',
            'type' => 'success'
        ];

        header("Location: http://127.0.0.1/vplumel/gstock-dclic-main/vue/commande.php"); // Redirigez vers la page de la vue principale des commandes
        exit();
    } catch (Exception $e) {
        die("Erreur : " . $e->getMessage());
    }
}
?>
